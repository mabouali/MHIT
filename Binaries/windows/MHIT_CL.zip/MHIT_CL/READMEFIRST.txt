MATLAB Hydrological Index Tool Command Line (MHIT_CL)
Written by: Mohammad Abouali (maboualimsu@gmail.com)

Refer to License section on https://github.com/mabouali/MHIT

Don't forget to cite the following journal paper:
- - Abouali, M., Daneshvar, F., Nejadhashemi, A.P., "MATLAB Hydrological Index Tool
    (MHIT): A high performance library to calculate 171 ecologically relvant 
    hydrological indices", Ecological Informatics, 17 March 2016,
    doi:10.1016/j.ecoinf.2016.03.004.

HOW TO INSTALL?
click on MHIT_Installer.exe and follow the instruction.
	
HOW TO EXECUTE MHIT_CL?
METHOD 1:
Click on MHIT_CL. It would ask you to choose the configuration file. All the indices 
are calculated then
NOTE: the first time that you execute this program, it may take few minutes 
before it starts. Please be patient.

METHOD 2: 
on command Prompt type:

MHIT_CL Path_to_Configuration_File

All the indices are calculated.

SAMPLE DATA & CONFIGURATION FILE:
a sample data set along with a configuration file is provided.
Note that before using this sample configuration file you need to edit it
to include proper paths to the sample data folder.


LICENSE:
Copyright (c) 2015, Mohammad Abouali (mabouali@gmail.com)

All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are 
permitted provided that the following conditions are met:

- - Redistributions of source code must retain the above copyright notice, this list 
    of conditions and the following disclaimer.
- - Redistributions in binary form must reproduce the above copyright notice, this list
    of conditions and the following disclaimer in the documentation and/or other materials
 	provided with the distribution.
- - It is being used only for noncommerical use and solely for academic and research purposes.
- - Cite the following journal paper:
- - - - Abouali, M., Daneshvar, F., Nejadhashemi, A.P., "MATLAB Hydrological Index Tool
        (MHIT): A high performance library to calculate 171 ecologically relvant 
        hydrological indices", Ecological Informatics, 17 March 2016,
        doi:10.1016/j.ecoinf.2016.03.004.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS 
OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
